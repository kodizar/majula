import * as mc from "@minecraft/server";

mc.system.afterEvents.scriptEventReceive.subscribe(event => {
  for (const player of mc.world.getPlayers()) {
    const wg = event.id.split("mello:")[1];
    const eventEntity = event.sourceEntity;
    switch (wg) {
      case "susanoo":
        susanoo(eventEntity);
      break
    }
  }
});

export function susanoo(eventEntity) {
  eventEntity.runCommandAsync('scoreboard objectives add susanoo dummy');
  eventEntity.runCommandAsync('scoreboard players set @s susanoo 1');
  eventEntity.setProperty('mello:susanoo', 1);
}

mc.world.afterEvents.entityHurt.subscribe(data => {
  const
    hurt = data.hurtEntity,
    damaging = data.damageSource.damagingEntity,
    damage = data.damage,
    item = hurt.getComponent('equippable').getEquipment('Head');
  if (hurt === undefined || damaging === undefined) return;
  if (hurt?.typeId == "minecraft:player" && item.typeId == "mello:mangekyou_sasuke" && hurt.getProperty('mello:susanoo') <= 50 && hurt.isSneaking) {
    hurt.runCommand(`scoreboard players add @s susanoo ${Math.floor(damage)}`);
    hurt.setProperty('mello:susanoo', getScore("susanoo", hurt) > 51 ? 51 : getScore("susanoo", hurt));
    console.warn(`${getScore("susanoo", hurt)} ${hurt.getProperty('mello:susanoo')}`);
  } else if (hurt?.typeId == "minecraft:player" && item.typeId == "mello:mangekyou_sasuke" && hurt.getProperty('mello:susanoo') > 50 && hurt.isSneaking) {
    console.warn(`2`);
    hurt.setProperty('mello:susanoo', 0);
  }
});

export function getScore(objective, player) { try { return mc.world.scoreboard.getObjective(objective).getScore(player.scoreboardIdentity); } catch (error) { return 0; } }

                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                                                                    
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                                                              