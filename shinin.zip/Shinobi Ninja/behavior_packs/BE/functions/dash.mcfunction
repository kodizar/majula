scoreboard objectives add dash dummy
scoreboard players set @s dash 0

gamerule sendcommandfeedback false

