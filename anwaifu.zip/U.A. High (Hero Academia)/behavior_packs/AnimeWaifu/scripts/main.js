import { world, Player, EquipmentSlot, system } from "@minecraft/server"; 
import { ModalFormData, ActionFormData } from "@minecraft/server-ui";

let previousPositions = new Map();

const getDistance = (pos1, pos2) => 
  Math.sqrt((pos1.x - pos2.x) ** 2 + (pos1.y - pos2.y) ** 2 + (pos1.z - pos2.z) ** 2);

system.runInterval(() => {
  for (const type of validEntityTypes) {
    for (const entity of world.getDimension('overworld').getEntities({ type })) {
      const currentPos = entity.location;
      const previousPos = previousPositions.get(entity);

      if (previousPos && getDistance(currentPos, previousPos) > 4) {
        const { x, y, z } = previousPos;
        entity.runCommandAsync(`fill ${x-1} ${y-1} ${z-1} ${x+1} ${y+2} ${z+1} air replace light_block ["block_light_level"=10]`);
      }

      previousPositions.set(entity, { ...currentPos });
    }
  }
}, 1);

const entitySelections = {};

const validEntityTypes = [
    "vb8:a2", "vb8:twob", "vb8:android_18", "vb8:aqua", "vb8:ashley",
    "vb8:asuka_langley", "vb8:bulma", "vb8:chika_fujiwara", "vb8:darkness",
    "vb8:elizabeth", "vb8:ellen_joe", "vb8:elma", "vb8:emilia", "vb8:fubuki",
    "vb8:gasai_yuno", "vb8:gwen_stacy", "vb8:hana_uzaki", "vb8:hayase_nagatoro",
    "vb8:hestia", "vb8:himiko_toga", "vb8:hitori_goto", "vb8:hinata", "vb8:ilulu",
    "vb8:komi", "vb8:lala_salatin_deviluke", "vb8:lucoa", "vb8:makima", 
    "vb8:mai_shiranui", "vb8:marin_kitagawa", "vb8:megumin", "vb8:mikasa", 
    "vb8:miku_nakano", "vb8:mitsuri", "vb8:morgiana", "vb8:nino_nakano", 
    "vb8:nobara_kugisaki", "vb8:power", "vb8:ram", "vb8:rei_ayanami", "vb8:rem", 
    "vb8:rin_tohsaka", "vb8:robin", "vb8:ruka", "vb8:shion", "vb8:shiraori", "vb8:tuka",
    "vb8:siesta", "vb8:taiga_aizaka", "vb8:tifa_lockhart", "vb8:tohru", 
    "vb8:tsukasa", "vb8:tsunade", "vb8:uta", "vb8:yor_forger", "vb8:yoruichi", 
    "vb8:yuugi_hoshiguma", "vb8:zero_two"
];

world.afterEvents.entityHitEntity.subscribe(({ damagingEntity, hitEntity }) => {
    if (!(damagingEntity instanceof Player) || !validEntityTypes.includes(hitEntity?.typeId)) return;

    const isTamedComponent = hitEntity.getComponent("is_tamed");
    if (!isTamedComponent) return;

    const playerEquippable = damagingEntity.getComponent("equippable");
    const item = playerEquippable.getEquipment(EquipmentSlot.Mainhand);
    if (!item || item.typeId !== 'vb8:waifu_wand') return;

    if (damagingEntity.isSneaking) {
        new ActionFormData()
            .title({ translate: 'waifu.delete_waifu' })
            .body({ translate: 'waifu.delete_prompt' })
            .button({ translate: 'waifu.yes' })
            .button({ translate: 'waifu.no' })
            .show(damagingEntity)
            .then(({ selection }) => {
                if (selection === 0) {
                    new ActionFormData()
                        .title({ translate: 'waifu.confirm_delete' })
                        .body({ translate: 'waifu.final_delete_warning' })
                        .button({ translate: 'waifu.delete_button' })
                        .button({ translate: 'waifu.cancel' })
                        .show(damagingEntity)
                        .then(({ selection }) => {
                            if (selection === 0) {
                                hitEntity.triggerEvent("minecraft:despawn");
                            }
                        });
                }
            });
        return;
    }

    const entityId = hitEntity.id;
    const playerId = damagingEntity.nameTag;
    const selectionKey = `${playerId}-${entityId}`;

    const sittingSelection = entitySelections[selectionKey]?.sitting ?? 0;
    const dancingSelection = entitySelections[selectionKey]?.dancing ?? 0;
    const showLife = entitySelections[selectionKey]?.showLife ?? 0;
    const movementSelection = entitySelections[selectionKey]?.movement ?? 0;
    const attackSelection = entitySelections[selectionKey]?.attack ?? 0;

    new ModalFormData()
        .title({ translate: 'waifu.interactions' })
        .dropdown({ translate: 'waifu.sitting_animations' }, [
            { translate: 'waifu.sit_1' }, { translate: 'waifu.sit_2' }, 
            { translate: 'waifu.sit_3' }, { translate: 'waifu.sit_4' }, 
            { translate: 'waifu.sit_5' }, { translate: 'waifu.sit_6' }
        ], sittingSelection)
        .dropdown({ translate: 'waifu.dance_animations' }, [
            { translate: 'waifu.dance_1' }, { translate: 'waifu.dance_2' }, 
            { translate: 'waifu.dance_3' }
        ], dancingSelection)
        .dropdown({ translate: 'waifu.life_visibility' }, [
            { translate: 'waifu.hide_life' }, { translate: 'waifu.show_life' }
        ], showLife)
        .dropdown({ translate: 'waifu.movement_mode' }, [
            { translate: 'waifu.random_walk' }, { translate: 'waifu.follow_owner' }
        ], movementSelection)
        .dropdown({ translate: 'waifu.attack_mode' }, [
            { translate: 'waifu.attack_monsters' }, { translate: 'waifu.attack_owner_hit' }
        ], attackSelection)
        .show(damagingEntity)
        .then(({ formValues }) => {
            const newSittingSelection = formValues[0];
            const newDancingSelection = formValues[1];
            const newShowLife = formValues[2];
            const newMovementSelection = formValues[3];
            const newAttackSelection = formValues[4];

            entitySelections[selectionKey] = {
                sitting: newSittingSelection,
                dancing: newDancingSelection,
                showLife: newShowLife,
                movement: newMovementSelection,
                attack: newAttackSelection
            };

            switch (newSittingSelection) {
                case 0: hitEntity.triggerEvent("minecraft:on_sitting_0"); break;
                case 1: hitEntity.triggerEvent("minecraft:on_sitting_1"); break;
                case 2: hitEntity.triggerEvent("minecraft:on_sitting_2"); break;
                case 3: hitEntity.triggerEvent("minecraft:on_sitting_3"); break;
                case 4: hitEntity.triggerEvent("minecraft:on_sitting_4"); break;
                case 5: hitEntity.triggerEvent("minecraft:on_sitting_5"); break;
            }

            switch (newDancingSelection) {
                case 0: hitEntity.triggerEvent("minecraft:on_dancing_0"); break;
                case 1: hitEntity.triggerEvent("minecraft:on_dancing_1"); break;
                case 2: hitEntity.triggerEvent("minecraft:on_dancing_2"); break;
            }

            switch (newShowLife) {
                case 0: hitEntity.triggerEvent("minecraft:hide_life"); break;
                case 1: hitEntity.triggerEvent("minecraft:show_life"); break;
            }

            switch (newMovementSelection) {
                case 0: hitEntity.triggerEvent("minecraft:random_walk_0"); break;
                case 1: hitEntity.triggerEvent("minecraft:follow_owner_0"); break;
            }

            switch (newAttackSelection) {
                case 0: hitEntity.triggerEvent("minecraft:attack_monsters_0"); break;
                case 1: hitEntity.triggerEvent("minecraft:attack_owner_hit_0"); break;
            }
        });
});
