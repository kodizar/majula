fill ~-1 ~-1 ~-1 ~1 ~4 ~1 air replace light_block ["block_light_level"=10]
fill ~ ~1 ~ ~ ~1 ~ light_block ["block_light_level"=10] replace air